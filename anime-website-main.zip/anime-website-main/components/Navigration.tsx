import React from "react";

const Navigration = () => {
  return (
    <nav className="flex justify-between p-7">
      <h1 className="text-white text-4xl">Animix</h1>
    </nav>
  );
};

export default Navigration;
